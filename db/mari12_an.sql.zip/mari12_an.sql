-- phpMyAdmin SQL Dump
-- version 4.0.8
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Фев 03 2014 г., 22:48
-- Версия сервера: 5.1.72-cll
-- Версия PHP: 5.3.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `mari12_an`
--

-- --------------------------------------------------------

--
-- Структура таблицы `average_flat_price`
--

CREATE TABLE IF NOT EXISTS `average_flat_price` (
  `date` date NOT NULL,
  `rooms` tinyint(1) NOT NULL,
  `price` int(8) NOT NULL,
  `area` float NOT NULL,
  `price_m` int(6) NOT NULL,
  KEY `date` (`date`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `city`
--

CREATE TABLE IF NOT EXISTS `city` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(40) NOT NULL,
  `region_id` int(2) NOT NULL,
  `lat` double DEFAULT NULL,
  `lon` double DEFAULT NULL,
  `dist` int(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `region_id` (`region_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1754 ;

-- --------------------------------------------------------

--
-- Структура таблицы `commercial`
--

CREATE TABLE IF NOT EXISTS `commercial` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `city_id` int(3) NOT NULL,
  `tenement_id` int(11) NOT NULL DEFAULT '0',
  `street_id` int(11) NOT NULL DEFAULT '0',
  `number` varchar(6) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `price` int(12) DEFAULT NULL,
  `price_m` int(7) DEFAULT NULL,
  `type_id` tinyint(2) NOT NULL DEFAULT '1',
  `total_area` float DEFAULT NULL,
  `description` text,
  `contacts` varchar(255) DEFAULT NULL,
  `is_owner` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `lat` double DEFAULT NULL,
  `lon` double DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `counter_views` int(5) NOT NULL DEFAULT '0',
  `quick_views` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `city_id` (`city_id`),
  KEY `status` (`status`),
  KEY `lat` (`lat`,`lon`),
  KEY `is_owner` (`is_owner`),
  KEY `tenement_id` (`tenement_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=216 ;

-- --------------------------------------------------------

--
-- Структура таблицы `commercial_visitors`
--

CREATE TABLE IF NOT EXISTS `commercial_visitors` (
  `id` int(11) NOT NULL,
  `ip` int(10) unsigned NOT NULL,
  `datetime` datetime NOT NULL,
  UNIQUE KEY `visitor` (`id`,`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `company`
--

CREATE TABLE IF NOT EXISTS `company` (
  `id` mediumint(4) NOT NULL AUTO_INCREMENT,
  `city_id` int(3) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(60) DEFAULT NULL,
  `contacts` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `birthday` mediumint(4) DEFAULT NULL,
  `description` text,
  `domain` varchar(30) DEFAULT NULL,
  `tariff_id` smallint(3) NOT NULL DEFAULT '1',
  `tariff_untill` date DEFAULT NULL,
  `lat` double DEFAULT NULL,
  `lon` double DEFAULT NULL,
  `type_id` tinyint(2) unsigned NOT NULL DEFAULT '1',
  `comments` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `domain` (`domain`),
  KEY `type_id` (`type_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=103 ;

-- --------------------------------------------------------

--
-- Структура таблицы `company_visitors`
--

CREATE TABLE IF NOT EXISTS `company_visitors` (
  `id` int(11) NOT NULL,
  `ip` int(10) unsigned NOT NULL,
  `counter_views` int(5) NOT NULL,
  `datetime` datetime NOT NULL,
  KEY `ip` (`ip`),
  KEY `counter_views` (`counter_views`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `district`
--

CREATE TABLE IF NOT EXISTS `district` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `city_id` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Структура таблицы `flat`
--

CREATE TABLE IF NOT EXISTS `flat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenement_id` int(11) NOT NULL,
  `number` int(4) DEFAULT NULL,
  `price` int(12) DEFAULT NULL,
  `price_m` int(7) DEFAULT NULL,
  `rooms` int(2) DEFAULT NULL,
  `is_new` tinyint(1) NOT NULL DEFAULT '0',
  `total_area` float DEFAULT NULL,
  `living_area` float DEFAULT NULL,
  `kitchen_area` float DEFAULT NULL,
  `storey` int(2) DEFAULT NULL,
  `is_corner` tinyint(1) DEFAULT NULL,
  `loggia` float DEFAULT NULL,
  `balcony` float DEFAULT NULL,
  `type_bathroom` tinyint(1) DEFAULT NULL,
  `bathroom_area` float DEFAULT NULL,
  `hall_area` float DEFAULT NULL,
  `height` float DEFAULT NULL,
  `condition` tinyint(1) DEFAULT NULL,
  `description` text,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `contacts` varchar(255) NOT NULL DEFAULT '-1',
  `is_owner` tinyint(1) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `created_on` datetime DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  `counter_views` int(5) NOT NULL DEFAULT '0',
  `quick_views` int(5) NOT NULL DEFAULT '0',
  `show_address` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `user_id` (`user_id`),
  KEY `storey` (`storey`),
  KEY `rooms` (`rooms`),
  KEY `is_corner` (`is_corner`),
  KEY `created_on` (`created_on`),
  KEY `type_bathroom` (`type_bathroom`),
  KEY `condition` (`condition`),
  KEY `is_owner` (`is_owner`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14263 ;

-- --------------------------------------------------------

--
-- Структура таблицы `flat_visitors`
--

CREATE TABLE IF NOT EXISTS `flat_visitors` (
  `id` int(11) NOT NULL,
  `ip` int(10) unsigned NOT NULL,
  `datetime` datetime NOT NULL,
  UNIQUE KEY `visitor` (`id`,`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `house`
--

CREATE TABLE IF NOT EXISTS `house` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `city_id` int(3) NOT NULL,
  `price` int(12) DEFAULT NULL,
  `price_m` int(7) DEFAULT NULL,
  `type_id` tinyint(2) NOT NULL DEFAULT '1',
  `total_area` float DEFAULT NULL,
  `living_area` float DEFAULT NULL,
  `land_area` float DEFAULT NULL,
  `storeys` tinyint(3) NOT NULL DEFAULT '1',
  `birthday` mediumint(4) DEFAULT NULL,
  `water` tinyint(1) DEFAULT NULL,
  `gas` tinyint(1) DEFAULT NULL,
  `electricity` tinyint(1) DEFAULT NULL,
  `height` float DEFAULT NULL,
  `street_id` int(4) DEFAULT NULL,
  `number` varchar(6) DEFAULT NULL,
  `description` text,
  `contacts` varchar(255) DEFAULT NULL,
  `is_owner` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `lat` double DEFAULT NULL,
  `lon` double DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `counter_views` int(5) NOT NULL DEFAULT '0',
  `quick_views` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `city_id` (`city_id`),
  KEY `status` (`status`),
  KEY `lat` (`lat`,`lon`),
  KEY `is_owner` (`is_owner`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1414 ;

-- --------------------------------------------------------

--
-- Структура таблицы `house_visitors`
--

CREATE TABLE IF NOT EXISTS `house_visitors` (
  `id` int(11) NOT NULL,
  `ip` int(10) unsigned NOT NULL,
  `datetime` datetime NOT NULL,
  UNIQUE KEY `visitor` (`id`,`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `land`
--

CREATE TABLE IF NOT EXISTS `land` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `city_id` int(3) NOT NULL,
  `price` int(12) DEFAULT NULL,
  `price_h` int(7) DEFAULT NULL,
  `area` float DEFAULT NULL,
  `water` tinyint(1) DEFAULT NULL,
  `gas` tinyint(1) DEFAULT NULL,
  `electricity` tinyint(1) DEFAULT NULL,
  `description` text,
  `contacts` varchar(255) DEFAULT NULL,
  `is_owner` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `lat` double DEFAULT NULL,
  `lon` double DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `counter_views` int(5) NOT NULL DEFAULT '0',
  `quick_views` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `city_id` (`city_id`),
  KEY `status` (`status`),
  KEY `lat` (`lat`,`lon`),
  KEY `is_owner` (`is_owner`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1363 ;

-- --------------------------------------------------------

--
-- Структура таблицы `land_visitors`
--

CREATE TABLE IF NOT EXISTS `land_visitors` (
  `id` int(11) NOT NULL,
  `ip` int(10) unsigned NOT NULL,
  `datetime` datetime NOT NULL,
  UNIQUE KEY `visitor` (`id`,`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `mailbox`
--

CREATE TABLE IF NOT EXISTS `mailbox` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `message_id` int(11) NOT NULL,
  `stat` int(3) NOT NULL DEFAULT '0',
  `date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `message`
--

CREATE TABLE IF NOT EXISTS `message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `message` varchar(1000) DEFAULT NULL,
  `status` int(3) NOT NULL DEFAULT '0',
  `date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `photo`
--

CREATE TABLE IF NOT EXISTS `photo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `object_id` int(11) NOT NULL,
  `kind_id` tinyint(2) NOT NULL,
  `tag` tinyint(2) NOT NULL,
  `name` varchar(64) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `created_on` datetime DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `object_id` (`object_id`),
  KEY `kind_id` (`kind_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16465 ;

-- --------------------------------------------------------

--
-- Структура таблицы `region`
--

CREATE TABLE IF NOT EXISTS `region` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  `code` varchar(13) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

-- --------------------------------------------------------

--
-- Структура таблицы `street`
--

CREATE TABLE IF NOT EXISTS `street` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `city_id` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8205 ;

-- --------------------------------------------------------

--
-- Структура таблицы `tenement`
--

CREATE TABLE IF NOT EXISTS `tenement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `city_id` int(3) NOT NULL DEFAULT '1',
  `district_id` int(6) DEFAULT NULL,
  `street_id` int(4) DEFAULT NULL,
  `number` varchar(6) DEFAULT NULL,
  `type_id` tinyint(2) NOT NULL DEFAULT '1',
  `storeys` tinyint(3) NOT NULL DEFAULT '1',
  `porches` tinyint(2) DEFAULT NULL,
  `lifts` tinyint(1) DEFAULT NULL,
  `birthday` mediumint(4) DEFAULT NULL,
  `type_roof` tinyint(1) DEFAULT NULL,
  `hot_water` tinyint(1) DEFAULT NULL,
  `type_heating` tinyint(1) DEFAULT NULL,
  `type_energy` tinyint(1) DEFAULT NULL,
  `elevators` tinyint(1) NOT NULL DEFAULT '0',
  `height` float DEFAULT NULL,
  `description` text,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `lat` double DEFAULT NULL,
  `lon` double DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `address` (`street_id`,`number`),
  KEY `city_id` (`city_id`),
  KEY `status` (`status`),
  KEY `lat` (`lat`,`lon`),
  KEY `birthday` (`birthday`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5465 ;

-- --------------------------------------------------------

--
-- Структура таблицы `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `login` varchar(24) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `company_id` mediumint(4) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `hash` varchar(50) DEFAULT NULL,
  `contacts` varchar(255) DEFAULT NULL,
  `comments` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `agency_id` (`company_id`),
  KEY `status` (`status`),
  KEY `name` (`name`),
  KEY `login` (`login`),
  KEY `hash` (`hash`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=157 ;

-- --------------------------------------------------------

--
-- Структура таблицы `user_updates`
--

CREATE TABLE IF NOT EXISTS `user_updates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `type_object` tinyint(1) NOT NULL,
  `object_id` int(11) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9330 ;

-- --------------------------------------------------------

--
-- Структура таблицы `_tmp_prices`
--

CREATE TABLE IF NOT EXISTS `_tmp_prices` (
  `date` date NOT NULL,
  `rooms` tinyint(1) NOT NULL,
  `price` int(8) NOT NULL,
  `area` float NOT NULL,
  `price_m` int(6) NOT NULL,
  `count_flats` int(4) DEFAULT NULL,
  KEY `date` (`date`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `_tmp_prices2`
--

CREATE TABLE IF NOT EXISTS `_tmp_prices2` (
  `date` date NOT NULL,
  `rooms` tinyint(1) NOT NULL,
  `price_m_p` int(6) NOT NULL,
  `price_m_k` int(6) NOT NULL,
  `price_m_n` int(6) NOT NULL,
  `price_h_l` int(6) DEFAULT NULL,
  `price_m_h` int(6) unsigned DEFAULT NULL,
  KEY `date` (`date`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
